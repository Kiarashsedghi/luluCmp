a=12
print(10<a<15)