a="asid2"
print(int(a[-1]))